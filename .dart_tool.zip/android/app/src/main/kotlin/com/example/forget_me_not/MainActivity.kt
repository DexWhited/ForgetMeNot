package com.example.forget_me_not

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
